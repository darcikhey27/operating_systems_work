#ifndef PROCESS_H
#define PROCESS_H

#include <string.h>
#include <stdio.h>
#include <stdlib.h>

void forkIt(char ** argv);

#endif
